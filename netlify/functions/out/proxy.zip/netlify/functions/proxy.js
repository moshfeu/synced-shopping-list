"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// proxy.ts
var proxy_exports = {};
__export(proxy_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(proxy_exports);
var handler = async (event, context) => {
  const { url } = event.queryStringParameters || {};
  if (!url) {
    return {
      statusCode: 400,
      body: "Missing url parameter"
    };
  }
  let decodedUrl;
  try {
    decodedUrl = decodeURIComponent(url);
  } catch (error) {
    console.log("Error decoding URL:", url, error);
    return {
      statusCode: 400,
      body: "Invalid URL parameter - malformed URI"
    };
  }
  console.log("Proxying image:", decodedUrl);
  let response;
  try {
    response = await fetch(decodedUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; synced-shopping-list)",
        Accept: "image/*",
        Referer: new URL(decodedUrl).origin
      }
    });
  } catch (error) {
    console.log("Error fetching URL:", decodedUrl, error);
    return {
      statusCode: 502,
      body: "Failed to fetch the image"
    };
  }
  const contentType = response.headers.get("Content-type") || "";
  if (!response.ok || !contentType.startsWith("image/")) {
    console.log(
      "Rejected response:",
      decodedUrl,
      `status ${response.status}`,
      `type ${contentType}`
    );
    return {
      statusCode: 502,
      body: `Not an image (status ${response.status}, type ${contentType})`
    };
  }
  const arrayBuffer = await response.arrayBuffer();
  const data = Buffer.from(arrayBuffer);
  const base64 = data.toString("base64");
  console.log("Proxied image:", decodedUrl, contentType, `${data.length} bytes`);
  return {
    headers: {
      "Content-type": contentType,
      "Content-Length": data.length,
      "Access-Control-Allow-Origin": "*"
    },
    isBase64Encoded: true,
    statusCode: 200,
    body: base64
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
